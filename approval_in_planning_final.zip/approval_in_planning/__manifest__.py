{
    'name': 'Approval Process',
    'version': '0.1',
    'category': 'custom',
    'summary': 'Approval Process',
    'license': 'AGPL-3',
    'description': """ """,
    'author': 'GlobalXS Technology Solutions',
    'website': 'http://www.globalxs.co',
    'depends': ['planning'],
    'data': [
        'security/ir.model.access.csv',
        'views/schedule_activity.xml',
        'views/schedulle.xml',
        'views/approval_view.xml',
        'views/kanban_view.xml',
        'views/planning_report.xml'
    ],
    'installable': True,
    'application': False,
    'auto_install': False,
}
