from odoo import models,fields,api, _
from datetime import datetime, timedelta

class approval(models.Model):
    _inherit = "planning.slot"

    employee_id = fields.Many2one('hr.employee', "Employee", group_expand='_read_group_employee_id', check_company=True)
    company_id = fields.Many2one('res.company', string="Company", required=True,related='employee_id.company_id',
                                 default=lambda self: self.env['res.company'])
    role_id = fields.Many2one('planning.role',related='employee_id.planning_role_id',string="Role")

    state = fields.Selection([
        ('draft', 'Draft'),
        ('approve1', 'Approve'),
        ('done', 'Done'),
        ('refuse', 'Refuse'),
    ], default="draft", track_visibility='always')

    def _get_responsible_for_approval(self):
        if self.state == 'approve1' and self.manager_id:
            return self.manager_id
        return self.env['res.users']

    def activity_update(self):
        to_clean, to_do = self.env['planning.slot'], self.env['planning.slot']
        for plan in self:
            if plan.state == 'draft':
                to_clean |= plan
            elif plan.state == 'approve1':
                plan.activity_schedule(
                    'planning.mail_act_schedule_approval',
                    user_id=plan.sudo()._get_responsible_for_approval().id or self.env.user.id)
            elif plan.state == 'done':
                to_clean |= plan

        if to_clean:
            to_clean.activity_unlink(['planning.mail_act_schedule_approval'])

    @api.multi
    def action_confirm1(self):
        self.write({'state': 'approve1',
                    'confirm_date': datetime.today(),
                    'confirm_by': self.env.uid})
        self.activity_update()
        return True

    @api.multi
    def action_approve2(self):
        self.write({'state': 'done'})
        self.activity_update()
        return True

    @api.multi
    def action_refuse1(self):
        self.write({'state': 'draft'})
        self.activity_update()
        return True